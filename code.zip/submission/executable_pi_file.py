import asyncio
import struct
import json
import time
from collections import defaultdict

import numpy as np
import torch
import torch.nn as nn
from bleak import BleakClient, BleakScanner
from bleak.exc import BleakError

# ================= BLE CONFIG =================
ADDRESS = "1C:C8:EF:C5:C0:15"   # Arduino MAC
NAME_HINT = "Nano33BLE-ClientNet"

# Arduino -> Pi (features)
FEAT_UUID = "7d1b5c2c-3c4e-4b8c-9a10-112233445566"

# Pi -> Arduino (binary result)
RESP_UUID = "7d1b5c2d-3c4e-4b8c-9a10-112233445566"

HEADER_LEN = 6
FRAME_TIMEOUT = 3.0

buffers = defaultdict(dict)
frame_time = {}

# ================= FEATURE SHAPE =================
IN_CHANNELS = 8
FEATURE_H = 4
FEATURE_W = 4
EXPECTED_LEN = IN_CHANNELS * FEATURE_H * FEATURE_W  # 128

# ================= PATHS =================
META_PATH = "/home/mypi13/artifacts/meta.json"
MODEL_PATH = "/home/mypi13/artifacts/server_conv_dogbin.pth"


# ================= MODEL =================
class ServerConvBinary(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(8, 16, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 16, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(16, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(1)


# ================= HELPERS =================
def load_scale():
    with open(META_PATH, "r") as f:
        return float(json.load(f)["calibration_scale"])


def load_model():
    model = ServerConvBinary()
    model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu"))
    model.eval()
    return model


def decode_features(raw: bytes, scale: float):
    if len(raw) != EXPECTED_LEN:
        raise ValueError(f"Expected {EXPECTED_LEN} bytes, got {len(raw)}")
    z = np.frombuffer(raw, dtype=np.int8).astype(np.float32)
    z = z * scale
    return torch.from_numpy(z).view(1, IN_CHANNELS, FEATURE_H, FEATURE_W)


def cleanup_frames():
    now = time.time()
    for fid in list(frame_time.keys()):
        if now - frame_time[fid] > FRAME_TIMEOUT:
            buffers.pop(fid, None)
            frame_time.pop(fid, None)


async def find_device():
    print("🔎 Scanning for Arduino...")
    devices = await BleakScanner.discover(timeout=6.0)

    for d in devices:
        if d.address and d.address.upper() == ADDRESS.upper():
            print(f"✅ Found device: {d.address}")
            return d

    for d in devices:
        if d.name and NAME_HINT in d.name:
            print(f"✅ Found device by name: {d.address}")
            return d

    return None


async def wait_for_services(client, timeout=12.0):
    end = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < end:
        if client.services is not None:
            return
        await asyncio.sleep(0.1)
    raise BleakError("Service discovery failed")


async def send_response(client, value: int):
    try:
        await client.write_gatt_char(RESP_UUID, bytes([value]), response=True)
        print(f"📤 Sent response to Arduino: {value}")
    except Exception as e:
        print("⚠️ Write failed:", e)


# ================= MAIN =================
async def main():
    scale = load_scale()
    model = load_model()

    print("✅ Model loaded")
    print("✅ calibration_scale =", scale)

    device = await find_device()
    if device is None:
        print("❌ Arduino not found")
        return

    client = BleakClient(device, timeout=60.0, dangerous_use_bleak_cache=False)
    await client.connect()
    print("✅ Connected to Arduino")

    await wait_for_services(client)

    def on_notify(sender, data: bytearray):
        cleanup_frames()

        if len(data) < HEADER_LEN:
            return

        frame_id, chunk_idx, total_chunks = struct.unpack_from("<HHH", data, 0)
        payload = bytes(data[HEADER_LEN:])

        if frame_id not in frame_time:
            frame_time[frame_id] = time.time()

        buffers[frame_id][chunk_idx] = payload

        if len(buffers[frame_id]) == total_chunks:
            full = b"".join(buffers[frame_id][i] for i in range(total_chunks))
            buffers.pop(frame_id, None)
            frame_time.pop(frame_id, None)

            print(f"✅ Frame {frame_id} received ({len(full)} bytes)")

            try:
                z = decode_features(full, scale)
                with torch.no_grad():
                    logit = float(model(z).item())
                is_dog = 1 if logit >= 0 else 0

                print(f"🧠 logit={logit:.4f} → dog={is_dog}")
                asyncio.create_task(send_response(client, is_dog))

            except Exception as e:
                print("❌ Inference error:", e)

    await client.start_notify(FEAT_UUID, on_notify)
    print("🔔 Listening for feature notifications...")

    while True:
        await asyncio.sleep(1.0)


if __name__ == "__main__":
    asyncio.run(main())
