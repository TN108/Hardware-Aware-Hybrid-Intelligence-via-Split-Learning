import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

# -----------------------------
# CONFIG
# -----------------------------
TRAIN_PT = "cache_features/train_feats.pt"
TEST_PT  = "cache_features/test_feats.pt"
OUT_DIR  = "artifacts"
OUT_PTH  = os.path.join(OUT_DIR, "server_conv_dogbin.pth")

DOG_LABEL = 5
BATCH_SIZE = 256
EPOCHS = 15
LR = 1e-3
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


# -----------------------------
# MODEL (remaining conv on Pi)
# -----------------------------
class ServerConvBinary(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(8, 16, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 16, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(16, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(1)  # [B]


# -----------------------------
# LOAD CACHED FEATURES
# -----------------------------
def load_cached(pt_path):
    if not os.path.exists(pt_path):
        raise FileNotFoundError(f"Missing file: {pt_path}")

    obj = torch.load(pt_path, map_location="cpu")

    if "features" not in obj or "labels" not in obj:
        raise ValueError(f"{pt_path} must contain 'features' and 'labels'")

    X = obj["features"].float()     # [N,8,4,4]
    y = obj["labels"]               # [N]

    if X.ndim != 4 or X.shape[1:] != (8, 4, 4):
        raise ValueError(f"Expected features [N,8,4,4], got {tuple(X.shape)}")

    # Binary labels
    y_bin = (y == DOG_LABEL).float()

    return X, y_bin


# -----------------------------
# MAIN
# -----------------------------
def main():
    print("Loading cached features...")
    Xtr, ytr = load_cached(TRAIN_PT)
    Xte, yte = load_cached(TEST_PT)

    print(f"Train: {Xtr.shape} | dog={int(ytr.sum())}/{len(ytr)}")
    print(f"Test : {Xte.shape} | dog={int(yte.sum())}/{len(yte)}")

    train_loader = DataLoader(
        TensorDataset(Xtr, ytr),
        batch_size=BATCH_SIZE,
        shuffle=True
    )

    test_loader = DataLoader(
        TensorDataset(Xte, yte),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    model = ServerConvBinary().to(DEVICE)

    # Handle class imbalance
    pos = ytr.sum().item()
    neg = len(ytr) - pos
    pos_weight = torch.tensor([neg / max(pos, 1)], device=DEVICE)

    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)

    print("\nTraining remaining-conv binary model...\n")

    best_acc = 0.0
    os.makedirs(OUT_DIR, exist_ok=True)

    for epoch in range(1, EPOCHS + 1):
        model.train()
        total_loss = 0.0

        for x, y in train_loader:
            x = x.to(DEVICE)
            y = y.to(DEVICE)

            optimizer.zero_grad()
            logits = model(x)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * y.size(0)

        avg_loss = total_loss / len(ytr)

        # ---- Eval ----
        model.eval()
        correct = 0
        total = 0

        with torch.no_grad():
            for x, y in test_loader:
                x = x.to(DEVICE)
                y = y.to(DEVICE)
                preds = (model(x) >= 0).float()
                correct += (preds == y).sum().item()
                total += y.numel()

        acc = 100.0 * correct / total
        print(f"Epoch {epoch:02d} | loss={avg_loss:.4f} | test_acc={acc:.2f}%")

        if acc > best_acc:
            best_acc = acc
            torch.save(model.state_dict(), OUT_PTH)

    print("\n✅ Training complete")
    print("✅ Saved model to:", OUT_PTH)
    print(f"Best test accuracy: {best_acc:.2f}%")


if __name__ == "__main__":
    main()
