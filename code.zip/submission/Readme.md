### Hardware-Aware Hybrid Intelligence via Split Learning

**Prerequisites**
- It is assumed that the Arduino is connected to the system.
- Arduino IDE is installed and properly configured.

**Arduino**
- Ensure `client_model.h` is placed in the same directory as the executable script.
- Open and execute `ExecutableScript.ino` using the Arduino IDE.

**Raspberry Pi**
- Transfer the `artifacts` directory to the Raspberry Pi.
- Run the executable Python script on the Raspberry Pi.
