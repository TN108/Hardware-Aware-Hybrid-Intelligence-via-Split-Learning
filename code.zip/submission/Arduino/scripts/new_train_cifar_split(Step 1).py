# new_train_cifar_improved.py
"""
Improved split-training for Arduino Nano 33 BLE:
- ClientNet: 3 conv layers -> final output 4x4x8 (128 values)
- ReLU6 activations for better quantization
- Two-phase training:
    Phase A: float training (client+server) for n_float_epochs
    Phase B: prepare QAT and fine-tune with quantization simulation for n_qat_epochs
- Fixed calibration scale computed from a few training batches to simulate deployment quantization
- Saves: client_float.pth, client_int8.pth (if conversion successful), server.pth
"""
import os
from dataclasses import dataclass
import math
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import torch.ao.quantization as tq
from typing import Tuple

# ----------------------------
# Config
# ----------------------------
@dataclass
class Config:
    data_root: str = "./data"
    batch_size: int = 128
    lr: float = 1e-3
    device: str = "cuda" if torch.cuda.is_available() else "cpu"

    # Training schedule
    n_float_epochs: int = 25   # phase A
    n_qat_epochs: int = 15     # phase B (QAT fine-tune)
    qat: bool = True

    # Arduino constraints
    client_out_channels: int = 8
    feature_h: int = 4
    feature_w: int = 4

    save_dir: str = "./artifacts"
    # Calibration
    calib_batches: int = 30  # number of batches to compute fixed scale


# ----------------------------
# Models
# ----------------------------
class ClientNet(nn.Module):
    """Tiny 3-conv ClientNet -> produces 4x4x8 feature map from 32x32 input"""
    def __init__(self, out_channels: int = 8):
        super().__init__()
        # conv block 1: 32 -> 16
        # conv block 2: 16 -> 8
        # conv block 3: 8 -> 4
        self.features = nn.Sequential(
            nn.Conv2d(3, 12, kernel_size=3, padding=1),
            nn.ReLU6(inplace=True),
            nn.MaxPool2d(2),          # 32 -> 16

            nn.Conv2d(12, 12, kernel_size=3, padding=1),
            nn.ReLU6(inplace=True),
            nn.MaxPool2d(2),          # 16 -> 8

            nn.Conv2d(12, out_channels, kernel_size=3, padding=1),
            nn.ReLU6(inplace=True),
            nn.MaxPool2d(2),          # 8 -> 4
        )

    def forward(self, x):
        return self.features(x)


class ServerNet(nn.Module):
    """Simple classifier that flattens 4x4x8 features -> 10 classes"""
    def __init__(self, in_channels=8, feature_h=4, feature_w=4, num_classes=10):
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(in_channels * feature_h * feature_w, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, num_classes),
        )

    def forward(self, z):
        return self.classifier(z)


# ----------------------------
# Data
# ----------------------------
def get_dataloaders(cfg: Config):
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2470, 0.2435, 0.2616)),
    ])
    trainset = torchvision.datasets.CIFAR10(root=cfg.data_root, train=True, download=True, transform=transform)
    testset = torchvision.datasets.CIFAR10(root=cfg.data_root, train=False, download=True, transform=transform)

    trainloader = torch.utils.data.DataLoader(trainset, batch_size=cfg.batch_size, shuffle=True, num_workers=2)
    testloader = torch.utils.data.DataLoader(testset, batch_size=cfg.batch_size, shuffle=False, num_workers=2)
    return trainloader, testloader


# ----------------------------
# Calibration: fixed scale for quantization simulation
# ----------------------------
def compute_calibration_scale(client: nn.Module, loader, device, num_batches: int = 30) -> float:
    """Run few batches through client to compute a fixed scale for feature quantization.
       We use symmetric quantization scale = max_abs / 127 (int8 symmetric range).
    """
    client.eval()
    with torch.no_grad():
        max_abs = 0.0
        count = 0
        for i, (x, _) in enumerate(loader):
            x = x.to(device)
            z = client(x)  # shape [B, C, H, W]
            cur_max_abs = float(z.abs().max().cpu().item())
            if cur_max_abs > max_abs:
                max_abs = cur_max_abs
            count += 1
            if count >= num_batches:
                break
    # avoid zero
    if max_abs <= 0:
        max_abs = 1e-6
    scale = max_abs / 127.0
    return float(scale)


# ----------------------------
# Utilities: quant sim
# ----------------------------
def quantize_tensor_int8(z: torch.Tensor, scale: float) -> Tuple[torch.Tensor, torch.Tensor]:
    """Quantize to signed int8 with provided scale (symmetric around 0),
       return (quantized_tensor_int8, dequantized_float_tensor).
    """
    q = torch.round(z / scale)
    q = torch.clamp(q, -128, 127).to(torch.int8)
    deq = q.float() * scale
    return q, deq


# ----------------------------
# Training loops
# ----------------------------
def train_phase(trainloader, client, server, optimizer, criterion, device, epoch_start, epochs,
                quantize=False, scale=None, print_prefix=""):
    """Train for given number of epochs. If quantize=True, apply quantization simulation with given scale."""
    for epoch in range(epoch_start, epoch_start + epochs):
        client.train()
        server.train()
        running_loss = 0.0
        total = 0
        correct = 0

        for inputs, labels in trainloader:
            inputs = inputs.to(device)
            labels = labels.to(device)
            optimizer.zero_grad()

            z = client(inputs)  # float activations

            if quantize:
                _, z_deq = quantize_tensor_int8(z, scale)
            else:
                z_deq = z

            outputs = server(z_deq)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * labels.size(0)
            _, preds = outputs.max(1)
            total += labels.size(0)
            correct += preds.eq(labels).sum().item()

        avg_loss = running_loss / total
        acc = 100.0 * correct / total
        print(f"{print_prefix}Epoch [{epoch+1}] Loss: {avg_loss:.4f} Acc: {acc:.2f}%")
    return


def eval_model(testloader, client, server, device, quantize=False, scale=None):
    client.eval()
    server.eval()
    total = 0
    correct = 0
    with torch.no_grad():
        for inputs, labels in testloader:
            inputs = inputs.to(device)
            labels = labels.to(device)
            z = client(inputs)
            if quantize:
                _, z_deq = quantize_tensor_int8(z, scale)
            else:
                z_deq = z
            outputs = server(z_deq)
            _, preds = outputs.max(1)
            total += labels.size(0)
            correct += preds.eq(labels).sum().item()
    acc = 100.0 * correct / total
    return acc


# ----------------------------
# Full training procedure
# ----------------------------
def train(cfg: Config):
    os.makedirs(cfg.save_dir, exist_ok=True)

    trainloader, testloader = get_dataloaders(cfg)

    client = ClientNet(out_channels=cfg.client_out_channels)
    server = ServerNet(in_channels=cfg.client_out_channels,
                       feature_h=cfg.feature_h, feature_w=cfg.feature_w)
    client.to(cfg.device)
    server.to(cfg.device)

    # optimizer & loss (train both models together)
    params = list(client.parameters()) + list(server.parameters())
    optimizer = optim.Adam(params, lr=cfg.lr)
    criterion = nn.CrossEntropyLoss()

    # ---- Phase A: Float training ----
    print("\n=== Phase A: Float training ===")
    train_phase(trainloader, client, server, optimizer, criterion, cfg.device,
                epoch_start=0, epochs=cfg.n_float_epochs, quantize=False, scale=None, print_prefix="[Float] ")

    float_test_acc = eval_model(testloader, client, server, cfg.device, quantize=False, scale=None)
    print(f"[Float] Test Accuracy after Phase A: {float_test_acc:.2f}%\n")

    # Save float client for reference
    torch.save(client.state_dict(), os.path.join(cfg.save_dir, "client_float.pth"))
    torch.save(server.state_dict(), os.path.join(cfg.save_dir, "server_float_after_phaseA.pth"))

    if not cfg.qat:
        # If QAT disabled, end here
        print("QAT disabled. Training finished.")
        return

    # ---- Compute calibration scale using a subset of training data ----
    print("Computing fixed quantization scale using representative batches...")
    scale = compute_calibration_scale(client.cpu(), trainloader, device="cpu", num_batches=cfg.calib_batches)
    # move back to device
    client.to(cfg.device)
    server.to(cfg.device)
    print(f"Calibration scale (symmetric) = {scale:.6f}")

    # ---- Prepare QAT: fuse -> qconfig -> prepare_qat ----
    print("\n=== Phase B: QAT fine-tuning ===")
    # fuse requires eval mode
    client.eval()
    # modules to fuse: conv + relu6 pairs
    modules_to_fuse = [
        ["features.0", "features.1"],
        ["features.3", "features.4"],
        ["features.6", "features.7"]
    ]
    try:
        tq.fuse_modules(client, modules_to_fuse, inplace=True)
        print("Fused modules for QAT.")
    except Exception as e:
        print("Fuse warning:", e)

    # ensure train mode before prepare_qat
    client.train()
    client.qconfig = tq.get_default_qat_qconfig("fbgemm")
    tq.prepare_qat(client, inplace=True)
    print("Client prepared for QAT.")

    # re-create optimizer if needed (recommended)
    optimizer = optim.Adam(list(client.parameters()) + list(server.parameters()), lr=cfg.lr * 0.5)

    # ---- QAT fine-tuning: use fixed scale quant simulation (to mimic Arduino) ----
    train_phase(trainloader, client, server, optimizer, criterion, cfg.device,
                epoch_start=cfg.n_float_epochs,
                epochs=cfg.n_qat_epochs,
                quantize=True, scale=scale,
                print_prefix="[QAT] ")

    # Evaluate with quantization simulation (server should adapt)
    qat_test_acc = eval_model(testloader, client, server, cfg.device, quantize=True, scale=scale)
    print(f"[QAT] Test Accuracy after Phase B (quantized simulation): {qat_test_acc:.2f}%")

    # ---- Convert to int8 (attempt) and save models ----
    print("\nSaving models...")
    # Save final float client + server
    torch.save(client.state_dict(), os.path.join(cfg.save_dir, "client_qat_floatstate.pth"))
    torch.save(server.state_dict(), os.path.join(cfg.save_dir, "server.pth"))

    # Convert to quantized model (eager)
    try:
        client_cpu = client.cpu()
        client_cpu.eval()
        client_int8 = tq.convert(client_cpu, inplace=False)
        torch.save(client_int8.state_dict(), os.path.join(cfg.save_dir, "client_int8.pth"))
        print("Saved quantized client_int8.pth")
    except Exception as e:
        print("Quantized conversion failed:", e)
        # Save float state as fallback
        torch.save(client.state_dict(), os.path.join(cfg.save_dir, "client_qat_floatstate_fallback.pth"))

    print("Training complete. Models saved in:", cfg.save_dir)
    return


# ----------------------------
if __name__ == "__main__":
    cfg = Config()
    train(cfg)
