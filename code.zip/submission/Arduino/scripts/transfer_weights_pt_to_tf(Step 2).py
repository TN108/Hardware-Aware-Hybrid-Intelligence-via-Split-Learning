import torch
import numpy as np
import tensorflow as tf

from new_train_cifar_split import ClientNet, Config
from client_tf_model import build_client_model

def main():
    cfg = Config()

    # -----------------------------
    # Load PyTorch ClientNet
    # -----------------------------
    pt_model = ClientNet(out_channels=cfg.client_out_channels)
    pt_model.load_state_dict(
        torch.load(f"{cfg.save_dir}/client_float.pth", map_location="cpu"),
        strict=True
    )
    pt_model.eval()

    # -----------------------------
    # Build TensorFlow Client model
    # -----------------------------
    tf_model = build_client_model()

    # Force build (initialize weights)
    dummy = np.zeros((1, 32, 32, 3), dtype=np.float32)
    tf_model(dummy)

    # -----------------------------
    # Extract PyTorch conv layers
    # -----------------------------
    pt_convs = [
        pt_model.features[0],  # Conv 1
        pt_model.features[3],  # Conv 2
        pt_model.features[6],  # Conv 3
    ]

    tf_convs = [
        tf_model.layers[1],  # Conv2D 1
        tf_model.layers[4],  # Conv2D 2
        tf_model.layers[7],  # Conv2D 3
    ]

    # -----------------------------
    # Copy weights
    # -----------------------------
    for i, (pt_conv, tf_conv) in enumerate(zip(pt_convs, tf_convs)):
        # PyTorch: (out_ch, in_ch, kH, kW)
        w_pt = pt_conv.weight.detach().cpu().numpy()
        b_pt = pt_conv.bias.detach().cpu().numpy()

        # Transpose to TF: (kH, kW, in_ch, out_ch)
        w_tf = np.transpose(w_pt, (2, 3, 1, 0))

        tf_conv.set_weights([w_tf, b_pt])
        print(f"✅ Copied Conv{i+1} weights: {w_tf.shape}")

    # -----------------------------
    # Save TensorFlow model
    # -----------------------------
    tf_model.export("client_tf_manual")
    print("\n🎉 TensorFlow ClientNet saved to: client_tf_manual/")

if __name__ == "__main__":
    main()
