import tensorflow as tf
import numpy as np
from PIL import Image

IMG_PATH = "captured_32x32.png"  # you already generate this in your image saver

def rep_dataset():
    for _ in range(200):
        img = Image.open(IMG_PATH).convert("RGB").resize((32, 32))
        x = np.asarray(img).astype(np.float32) / 255.0
        x = x.reshape(1, 32, 32, 3)  # NHWC
        yield [x]

def main():
    converter = tf.lite.TFLiteConverter.from_saved_model("client_tf_manual")
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = rep_dataset
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8

    tflite_model = converter.convert()
    open("client_int8.tflite", "wb").write(tflite_model)
    print("✅ Wrote client_int8.tflite")

if __name__ == "__main__":
    main()
