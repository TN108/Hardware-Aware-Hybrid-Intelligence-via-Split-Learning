import pathlib

def main():
    tflite_path = pathlib.Path("client_int8.tflite")
    if not tflite_path.exists():
        raise FileNotFoundError("client_int8.tflite not found")

    data = tflite_path.read_bytes()

    with open("client_model.h", "w") as f:
        f.write("const unsigned char client_model[] = {\n")
        for i, b in enumerate(data):
            if i % 12 == 0:
                f.write(" ")
            f.write(f"0x{b:02x}, ")
            if i % 12 == 11:
                f.write("\n")
        f.write("\n};\n")
        f.write(f"const unsigned int client_model_len = {len(data)};\n")

    print("✅ Wrote client_model.h")
    print(f"Model size: {len(data)} bytes")

if __name__ == "__main__":
    main()
